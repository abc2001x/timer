<?php

$loader = new \Phalcon\Loader();
$loader->registerNamespaces(['ReactQue'=>dirname(__DIR__).'/react_phalcon'])->register();

$r=\ReactQue\Utils::addTimer('\\ReactQue\\Utils','test',5,['wuguoxuan']);
echo $r.PHP_EOL;
var_dump($r);

