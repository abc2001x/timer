<?php
namespace ReactQue;

class Ctrl extends BaseCtrl{

    public function hello(){
        $loop = $this->loop;
        $loop->addTimer(5,  function (){
                                echo  'dddddd'.PHP_EOL;
                            }
                        );
        // $r = $t->addTask('\\Library\\Test','test',10,$params=[]);
        return 'hello world!`````';
    }

    public function not_found(){
        return 'not found!';   
    }

    public function add_timer(){
        $data = $this->getData();
        if (!$data) {
            return 'fail';
        }

        $data = json_decode($data);
       
        $class = $data->class;
        $method = $data->method;
        $params = $data->params;
        $exec_time = $data->exec_time;
        $now = time();
        $loop = $this->loop;
        
        $task = \ReactQue\Timer::addTask($class,$method,$exec_time,$params);
        if (!$task) {
            return 'fail';
        }
        $futureTime = $exec_time-$now;
        // echo $futureTime.PHP_EOL;
        $loop->addTimer($futureTime,function()use($task){
            $params = json_decode($task->params);
            $className = $task->class;
            $methodName = $task->method;

            if (method_exists($className,$methodName)) {
                Utils::call_func($className,$methodName,$params);
                $task->delete();
                // \ReactQue\Timer::cleanTask();
            }
            // $method->invokeArgs
            // $o = new $className();
            // $o->{$methodName}();
            // call_user_func_array([$className,$methodName], $params);
            echo "timer called".PHP_EOL;
        });

        return 'ssss';
    }
}