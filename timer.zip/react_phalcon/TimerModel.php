<?php
/**
 * 与open_platform表映射
 * User: wangjiankun
 * Date: 15/8/29
 * Time: 11:42
 */

namespace ReactQue;

use Phalcon\Mvc\Model;

class TimerModel extends Model {

    public $id;
    public $ctime;
    public $class;
    public $method;
    public $params;
    public $exec_time;
    // public $is_consume;

    public function beforeCreate() {
        $this->ctime = time();
        $this->is_consume = 0;
        
    }

    public function getSource() {
        return "timer_task";
    }
    

}
