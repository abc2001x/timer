<?php
namespace ReactQue;
class Timer
{
    public static $min_exec_time = null;
    public static $last_timer=null;
    public static $last_time=null;

    const TIMER_API = 'http://localhost:1337/add_timer';

    public function __construct(){

    }

    /**
     * 只存储最小的执行时间
     * @author wugx
     * @version     1.0
     * @date        2015-11-15
     * @anotherdate 2015-11-15T03:55:48+0800
     * @param       [type]                   $second [description]
     */
    public static function setMinExecTime($second){
        //比较数据库中最小的执行时间 和 新添加的定时任务时间,存储最小的那个时间,用作定时器中
        $time = $second;
        $minModel = TimerModel::findFirst(['is_consume=0','order'=>'exec_time']);

        $modelMinTime = $minModel->exec_time;

        $time = $modelMinTime < $time ? $modelMinTime : $time;

        if (self::$min_exec_time) {
            self::$min_exec_time = self::$min_exec_time > $time ? $time : self::$min_exec_time > $time ;
            
        }
        else
        {
            self::$min_exec_time = $time;    
        }
        
        // echo '最小执行时间:'.self::$min_exec_time.PHP_EOL;
    }

    public static function getMinExecTime(){
        return self::$min_exec_time;
    }


    public static function requestTimer($fullClassName,$methodName,$second,$params=[]){
        $data = ['class'=>$fullClassName,'method'=>$methodName,'exec_time'=>time()+$second,'params'=>$params];
        $return = self::sendDataByCurl(self::TIMER_API,$data);
        if ('fail'==$return) {
            return false;
        }
        else
        {
            return true;
        }
    }

    /**
     * 添加定时任务
     * @author wugx
     * @version     1.0
     * @date        2015-11-15
     * @anotherdate 2015-11-15T03:51:58+0800
     * @param       [type]                $fullClassNameAndMethod \namespace\classname:method
     * @param       int                   $second                 执行时间戳
     * @param       array                 $params                 参数
     */
    public static function addTask($fullClassName,$methodName,$exec_time,$params=[]){
        if (!method_exists($fullClassName,$methodName)) {
            return false;
        }
        // echo '添加任务:'.self::$min_exec_time.PHP_EOL;
        $model = new TimerModel();
        $model->class=$fullClassName;
        $model->method=$methodName;
        $model->params=json_encode($params);
        $model->exec_time = $exec_time;
        if ($model->save()) {
            // self::setMinExecTime($model->exec_time);
            return $model;
        }
        else
        {
            return false;
        }


    }

    public static function cleanTask(){
        $tasks = TimerModel::find(['exec_time <= :time:','bind'=>['time'=>time()]]);
        foreach ($tasks as $v) {
            $className = $v->class;
            $methodName = $v->method;
            $params = json_decode($v->params,1);
            if (method_exists($className, $methodName)) {
                Utils::call_func($className, $methodName,$params);
                // $r = call_user_func_array([$className,$methodName], $params);
                echo $v->id.' 执行'.$className.'->'.$methodName.'('.$v->params.') 成功'.PHP_EOL;
                $v->delete();
            }
        }
    }

    public static function sendDataByCurl($url,$data=array()){
        //对空格进行转义
        $url = str_replace(' ','+',$url);
        $ch = curl_init();
        $data_string=json_encode($data);
        //设置选项，包括URL
        curl_setopt($ch, CURLOPT_URL, "$url");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch,CURLOPT_TIMEOUT,3);  //定义超时3秒钟 
         // POST数据
        curl_setopt($ch, CURLOPT_POST, 1);
        // 把post的变量加上
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);    //所需传的数组用http_bulid_query()函数处理一下，就ok了
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string))
        );
        //执行并获取url地址的内容
        $output = curl_exec($ch);
        $errorCode = curl_errno($ch);
        //释放curl句柄
        curl_close($ch);
        if(0 !== $errorCode) {
            return false;
        }
        return $output;
    }

}