<?php
namespace ReactQue;
//加载公共类命名空间,加载后的用法如下:
require __DIR__.'/../vendor/autoload.php';
use Phalcon\Mvc\Router;
use Phalcon\Loader;

class React{
    private static $loop=null;
    const PORT = 1337;

    private $router=null;

    public static function getLoop(){
        if (!self::$loop) {
            self::$loop = \React\EventLoop\Factory::create();
        }
        return self::$loop;
    }

    public function initPhalcon(){
        $loader = new Loader();
        $loader->registerNamespaces(['ReactQue'=>__DIR__])->register();

        $this->router = new Router();
        $this->router->add(
            "/:action/:params",
            array(
                // 'namespace'  => 'Backend\Controllers',
                'controller' => 'Ctrl',
                'action'     => 1,
                'params'     => 2,
            )
        );

        $di = new \Phalcon\DI\FactoryDefault();        
        // Setup the database service
        $di->set('db', function () {
            return new \Phalcon\Db\Adapter\Pdo\Mysql(array(
                "host"     => "58.83.223.235",
                "username" => "root",
                "password" => "root",
                "dbname"   => "rookie",
                "charset"  => "utf8"
            ));
        });
    }

    public function __construct(){
        if (!self::$loop) {
            self::$loop = \React\EventLoop\Factory::create();
        }
        $this->initPhalcon();
        //清理定时任务
        Timer::cleanTask();
    }

    public function onRequest($request,$response){
        echo "string".PHP_EOL;
    }

    public function writeHeader($code=200,$params=['Content-Type' => 'text/plain']){

        return ;
    }

    public function sendData($data){

    }

    public function add_timer($time,$callback){

    }

    private function handle($request,$response,$data=null){
        $path = $request->getPath();
        $router = $this->router;
        $router->handle($path);

        $controller = $router->getControllerName();
        $className = 'ReactQue\\'.$controller;
        $action =  $router->getActionName();
        $ctrl = null;
        if (!$controller || !$action) {
            $ctrl = new Ctrl($request,$response);
            return $ctrl->not_found();
        }

        if(class_exists($className)){
            $ctrl = new $className($request,$response);
            $params = $router->getParams();

            if (method_exists($ctrl,$action)) {
                try {
                    $ctrl->setData($data);
                    $result = call_user_func_array([$ctrl,$action], $params);    
                } catch (Exception $e) {
                    $result = 'fail';
                }
                
                return $result;

            }
            else
            {
                return $ctrl->not_found();
            }
        }

        $ctrl = new Ctrl($request,$response);
        return $ctrl->not_found();
    }

    public function run(){
        $socket = new \React\Socket\Server(self::$loop);
        $http = new \React\Http\Server($socket);

        $http->on('request',function($request,$response){
            if (strtolower($request->getMethod())=='post') {
                $request->on('data',function($data) use($request,$response){
                    $content = $this->handle($request,$response,$data);
                    unset($request);
                    $response->end($content);
                });
            }
            else
            {
                $content = $this->handle($request,$response);
                unset($request);
                $response->end($content);
            }

        });

        $socket->listen(self::PORT);
        $loop = self::$loop;
        $i = 0;
        $loop->addPeriodicTimer(2, function () use (&$i) {
            $kmem = memory_get_usage(true) / 1024;
            echo "Request: $i\n";
            echo "Memory: $kmem KiB\n";
        });
        self::$loop->run();

    }
}