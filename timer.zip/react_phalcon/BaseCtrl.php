<?php
namespace ReactQue;

class BaseCtrl{
    private $request ;
    private $response ;
    public $loop;
    private $data;

    public function __construct($request,$response){

        $this->request=$request;
        $this->response = $response;
        $this->loop = React::getLoop();

        $response->writeHead(200,['Content-Type' => 'text/plain']);
    }

    public function getData(){
        return $this->data;
    }

    public function setData($data){
        $this->data = $data;
    }

}